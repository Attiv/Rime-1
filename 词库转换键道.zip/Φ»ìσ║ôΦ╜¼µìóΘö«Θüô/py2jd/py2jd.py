# All.txt，存放需要转换的词组，每行一词，无多余编码
# jdx.csv，单字的首笔形码，用的 RIME_JD 的单字码表
# jdAllx.csv，最后得到的键道音形码文件

# 导入需要的模块
import re, csv, pandas, os
from pypinyin import pinyin, lazy_pinyin, Style

# 判断文件是否存在
file_list = ['jdAll.csv', 'jdAllx.csv', 'jdf.csv', 'jdy.csv', 'jdyf.csv', 'pinyin.csv']
for file in file_list:
    if os.path.exists(file):
        os.remove(file)

# 把词组存储到 Alltxt 列表中
with open('All.txt', 'r', encoding='UTF-8-SIG') as f:
    Alltxt = f.readlines()

# 使用 pyinyin 为词组注音，并写入 pinyin.csv
with open('pinyin.csv', 'w', encoding='UTF-8') as Allpinyin:
    for ci in Alltxt:
        Allpinyin.write(ci.rstrip()+'\t')
        sh = lazy_pinyin(ci, style=Style.INITIALS, strict=False, errors='ignore') # 取声母为列表
        un = lazy_pinyin(ci, style=Style.FINALS, strict=False, errors='ignore') #取韵母为列表
        n = 0
        while n < len(un):
            Allpinyin.write(sh[n]+'\''+un[n]+'\t')
            n += 1
        Allpinyin.write('\n')

# 提取含飞键的词组到 jdf.csv，以便另外处理
# 将全拼词组变为列表
with open('pinyin.csv', 'r', encoding='UTF-8') as file1:
    data1 = file1.readlines()
# 提取飞键
with open('jdf.csv', 'w', encoding='UTF-8') as file2:
    for line in data1:
        n = re.findall(r".*\t(ch'ao|ch'e|zh'ai|zh'ao|zh'e|ch'uang|g'uang|h'uang|k'uang|sh'uang|zh'uang)\t.*", line)
        if n:
            file2.writelines(line)

# 准备把全拼转成键道双拼
dict1 = {'\t\'':'\tx\'', '\tj\'u\t':'\tjl\t', '\tq\'u\t':'\tql\t', '\tx\'u\t':'\txl\t', '\ty\'u\t':'\tyl\t'} # 零声母引导
dict2 = {'\'iu\t':'q\t', '\'ua\t':'q\t', '\'ei\t':'w\t', '\'un\t':'w\t', '\'e\t':'e\t', '\'eng\t':'r\t', '\'uan\t':'t\t', '\'iong\t':'y\t', '\'ong\t':'y\t', '\'ang\t':'p\t', '\'a\t':'s\t', '\'ia\t':'s\t', '\'ie\t':'d\t', '\'ou\t':'d\t', '\'an\t':'f\t', '\'ing\t':'g\t', '\'uai\t':'g\t', '\'ai\t':'h\t', '\'ue\t':'h\t', '\'ve\t':'h\t', '\'er\t':'j\t', '\'u\t':'j\t', '\'i\t':'k\t', '\'o\t':'l\t', '\'uo\t':'l\t', '\'v\t':'l\t', '\'ao\t':'z\t', '\'iang\t':'x\t', '\'iao\t':'c\t', '\'in\t':'b\t', '\'ui\t':'b\t', '\'en\t':'n\t', '\'n\t':'n\t', '\'ian\t':'m\t'} # 韵母
dicta = {'\tch':'\tj', '\tzh':'\tq', '\tsh':'\te', '\'uang':'m'} # 飞键1
dictb = {'\tch':'\tw', '\tzh':'\tf', '\tsh':'\te', '\'uang':'x'} # 飞键2

# 把词组列表转换为字符串
allPY = "".join(data1)
# 先将特殊编码及零声母搞定
for k, v in dict1.items():
    allPY = allPY.replace(k, v)
# 固定飞键替换
allPY = re.sub("\t(ch)(\')(ai|an|ang|en|eng|u|un)\t", r"\tj\2\3\t", allPY)
allPY = re.sub("\t(ch)(\')(a|i|ong|ou|ua|uai|uan|uang|ui|uo)\t", r"\tw\2\3\t", allPY)
allPY = re.sub("\t(zh)(\')(an|ang|ei|en|eng|u|un)\t", r"\tq\2\3\t", allPY)
allPY = re.sub("\t(zh)(\')(a|i|ong|ou|ua|uai|uan|uang|ui|uo)\t", r"\tf\2\3\t", allPY)
# 飞键1替换
for k, v in dicta.items():
    allPY = allPY.replace(k, v)
# 韵母替换
for k, v in dict2.items():
    allPY = allPY.replace(k, v)
# 将键道音码存入 jdy.csv 文件
with open('jdy.csv', 'w', encoding='UTF-8') as file2:
    file2.write(allPY)

# 不管了，直接飞键再运行一遍
with open('jdf.csv', 'r', encoding='UTF-8') as file3:
    data3 = file3.readlines()
allPYf = "".join(data3)
# # 先将特殊编码及零声母搞定
for k, v in dict1.items():
    allPYf = allPYf.replace(k, v)
# # 固定飞键替换
allPYf = re.sub("\t(ch)(\')(ai|an|ang|en|eng|u|un)\t", r"\tj\2\3\t", allPYf)
allPYf = re.sub("\t(ch)(\')(a|i|ong|ou|ua|uai|uan|uang|ui|uo)\t", r"\tw\2\3\t", allPYf)
allPYf = re.sub("\t(zh)(\')(an|ang|ei|en|eng|u|un)\t", r"\tq\2\3\t", allPYf)
allPYf = re.sub("\t(zh)(\')(a|i|ong|ou|ua|uai|uan|uang|ui|uo)\t", r"\tf\2\3\t", allPYf)
# # 飞键2替换
for k, v in dictb.items():
    allPYf = allPYf.replace(k, v)
# # 韵母替换
for k, v in dict2.items():
    allPYf = allPYf.replace(k, v)
# # 将键道音码存入 jdy.csv 文件
with open('jdyf.csv', 'w', encoding='UTF-8') as file4:
    file4.write(allPYf)

# 输出音形码
with open('jdy.csv', 'r+', newline="", encoding='UTF-8') as csvf:
    with open('jdAll.csv', 'w', encoding='UTF-8') as jda:
        rows = csv.reader(csvf, dialect=csv.excel_tab)
        for row in rows:
            if len(row) <= 4:
                sy1 = row[1][:2]
                sy2 = row[2][:2]
                jda.write(row[0]+'\t'+sy1+sy2+'\n')
            elif len(row) <= 5:
                s1 = row[1][:1]
                s2 = row[2][:1]
                s3 = row[3][:1]
                jda.write(row[0]+'\t'+s1+s2+s3+'\n')
            else:
                s1 = row[1][:1]
                s2 = row[2][:1]
                s3 = row[3][:1]
                s4 = row[-2][:1]
                jda.write(row[0]+'\t'+s1+s2+s3+s4+'\n')
            # print(row)

# 追加飞键
with open('jdyf.csv', 'r+', newline="", encoding='UTF-8') as csvf:
    with open('jdAll.csv', 'a', encoding='UTF-8') as jda:
        jda.write('\n'+'# =========以下是飞键========='+'\n')
        rows = csv.reader(csvf, dialect=csv.excel_tab)
        for row in rows:
            if len(row) <= 4:
                sy1 = row[1][:2]
                sy2 = row[2][:2]
                jda.write(row[0]+'\t'+sy1+sy2+'\n')
            elif len(row) <= 5:
                s1 = row[1][:1]
                s2 = row[2][:1]
                s3 = row[3][:1]
                jda.write(row[0]+'\t'+s1+s2+s3+'\n')
            else:
                s1 = row[1][:1]
                s2 = row[2][:1]
                s3 = row[3][:1]
                s4 = row[-2][:1]
                jda.write(row[0]+'\t'+s1+s2+s3+s4+'\n')
            # print(row)

# 去除追加飞键中对编码无影响的三词及以上的 'uang'
data4 = pandas.read_csv('jdAll.csv', dialect=csv.excel_tab, encoding='UTF-8')
data5 = data4.drop_duplicates(keep='first', inplace=False)
data5.to_csv('jdAll.csv', index=None, sep='\t', encoding='UTF-8')

# 将首笔对应码转为字典
dictx = {}
with open('jdx.csv', 'r+', encoding='UTF-8') as f:
    reader=csv.reader(f, dialect=csv.excel_tab)
    for row in reader:
        dictx[row[0]]=row[1]

# 开始添加形码，最核心、最常用的词库可以不加形码以降低码长
# 把音码存为列表
with open('jdAll.csv', 'r', encoding='UTF-8') as file:
    datax = file.readlines()

# 添加形码
with open('jdAllx.csv', 'w', encoding='UTF-8') as jdAllx:
    for cizu in datax:
        if len(cizu)==8 and cizu[2]!='\t':
            try:
                x1 = dictx[cizu[0]]
                x2 = dictx[cizu[1]]
                x3 = dictx[cizu[2]]
                jdAllx.write(cizu[:-1] + x1 + x2 + x3 + '\n')
            except Exception as e:
                print(e)
        elif len(cizu)==27: # 飞键分割线
            jdAllx.write(cizu)
        else :
            try:
                x1 = dictx[cizu[0]]
                x2 = dictx[cizu[1]]
                jdAllx.write(cizu[:-1] + x1 + x2 + '\n')
            except Exception as e:
                print(e)