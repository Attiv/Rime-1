
# 在当前目录下搞一个 xkjd6.dict.yaml ，并将所有词库复制进去
# xkjd6.dict.yaml 格式为「词组 编码」，中间为制表符

import glob
import os


key_set = set()
len6 = set()
other_len6 = set()
result = set()
other_result = set()


def all_dict_handle(content):

    for line in content:
        key = line.split('\t')[1]
        if len(key) == 7:
            len6.add(line)
        else:
            other_len6.add(line)

    with open('len6.txt', 'w', encoding='utf-8') as f:
        f.write(''.join(len6))

    with open('other_len6.txt', 'w', encoding='utf-8') as f:
        f.write(''.join(other_len6))


def dynamic_length(content):

    with open('other_len6.txt', 'r', encoding='utf-8') as f:
        content_other_len6= f.readlines()

    for line in content_other_len6:
        other_len6.add(line)

    for line in content:
        key = line.split('\t')[1]
        if len(key) == 7:
            if key[:-2]+"\n" not in other_len6:
                
                if key[:-2] not in key_set:
                    result.add(line[:-2])       
                else:
                    other_result.add((line))

                key_set.add(key[:-2])
        else:
            other_result.add((line))

    with open('result.txt', 'w', encoding='utf-8') as f:
        f.write('\n'.join(result))

    with open('other_result.txt', 'w', encoding='utf-8') as f:
        f.write(''.join(other_result))


def merge_files(file_names, output_file):
    with open(output_file, 'w') as outfile:
        for file_name in file_names:
            with open(file_name, 'r') as infile:
                outfile.write(infile.read())


def clean_files():
    # 使用 glob 获取所有文件
    files = glob.glob('./*.txt')
    # 清理 results
    for f in files:
        try:
            os.remove(f)
            print(f"Deleted file: {f}")
        except Exception as e:
            print(f"Cannot delete file {f}. Reason: {e}")


def main():

    if os.path.exists('dynamic_length.yaml'):
        os.remove('dynamic_length.yaml')

    # 读取词库所有词组内容
    with open('xkjd6.dict.yaml', 'r', encoding='utf-8') as f:
        content = f.readlines()

    # 分出 「6 码」和 「6 码之外」
    all_dict_handle(content)

    # 对 「6 码」 分出 「5 码」和 「6 码」
    dynamic_length(content)

    # 合并文件
    merge_files(['result.txt', 'other_result.txt'], 'dynamic_length.yaml')

    # 清理 txt
    clean_files()


if __name__ == '__main__':
    main()