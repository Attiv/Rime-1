使用：
1、将需要转换的词库复制进 py2jd/All.txt 中，每行一词，无多余编码
2、在 py2jd 目录下执行 python3 py2jd.py ，生成的拼音词库文件为 py2jd/jdAll.csv，（留意 requirements.txt）
在执行完 python3 py2jd.py 后，终端可能会输出一些字，说明这些字不在 py2jd/jdx.csv 中，如果确实需要该字，自行添加至 py2jd/jdx.csv，并加入第一笔的笔画码。
3、执行 python3 gen.py 完成纯音空码的转换

输出文件：
在 results 目录下分为有重复和无重复的 yaml 文件。