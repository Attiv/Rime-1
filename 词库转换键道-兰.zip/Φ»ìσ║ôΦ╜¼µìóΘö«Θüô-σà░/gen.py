import os
import random
import glob
import re

splited_files = ['./results/length_2.txt',
                 './results/length_3.txt',
                 './results/length_4.txt',
                 './results/length_5.txt']

jd_bm_file = './results/jd_bm_result.txt'

# 匹配的正则表达式
pattern = r'^.*\t[a-z]*'
output_zc_file = "./results/jd_zc_result.txt"
output_bm_file = "./results/jd_bm_result.txt"

def jd_bm():

    file_list = [output_zc_file, output_bm_file]
    for file in file_list:
        if os.path.exists(file):
            os.remove(file)
    
    # 打开输出文件
    with open(output_bm_file, 'w') as outfile_ci, open(output_zc_file, 'w') as outfile_bm: 
        # 遍历目录下的所有yaml文件
        for filename in glob.glob('./Rime_JD/*.yaml'):
            # 打开yaml文件
            with open(filename, 'r') as infile:
                # 读取yaml文件中的所有行
                lines = infile.readlines()
                # 遍历每一行，匹配正则表达式，将匹配结果写入输出文件
                for line in lines:
                    if re.search(pattern, line):
                        outfile_bm.write(line.split("\t")[0]+"\n")
                        outfile_ci.write(line.split("\t")[1])

def split_from_jpy2jd(file_list):
    for file in file_list:
        if os.path.exists(file):
            os.remove(file)

    # 打开所有的输出文件
    with open('./results/length_2.txt', 'w', encoding='utf-8') as f2, \
            open('./results/length_3.txt', 'w', encoding='utf-8') as f3, \
            open('./results/length_4.txt', 'w', encoding='utf-8') as f4, \
            open('./results/length_5.txt', 'w', encoding='utf-8') as f5:
        # 打开并读取原始文件中的内容
        with open('./py2jd/jdAll.csv', 'r', encoding='utf-8') as f:
            for line in f:
                # 根据长度将内容写入对应的文件
                length = len(line.split('\t')[0])
                if length == 2:
                    f2.write(line)
                elif length == 3:
                    f3.write(line)
                elif length == 4:
                    f4.write(line)
                elif length >= 5:
                    f5.write(line)


def get_result(file_name):
    # 读取 ./results/jd_bm_result.txt 文件中的内容，存储在集合中
    with open(jd_bm_file, 'r', encoding='utf-8') as f:
        c_set = set(line.strip() for line in f)

    # 读取文件中的内容
    with open(file_name, 'r', encoding='utf-8') as f:
        length_2_lines = f.readlines()

    # 过滤掉存在于 ./results/jd_bm_result.txt 的行
    filtered_lines = [line for line in length_2_lines if line.split('\t')[
        1].strip() not in c_set]

    # 将结果写入新的文件
    with open(file_name + '_result.txt', 'w', encoding='utf-8') as f:
        for line in filtered_lines:
            f.write(line)


def sorted(file_name):
    # 创建一个字典存储拼音及其出现次数
    pinyin_dict = {}

    # 读取 result.txt 文件中的内容
    with open(file_name, 'r', encoding='utf-8') as f:
        lines = f.readlines()

        # 统计拼音出现的次数
        for line in lines:
            pinyin = line.split('\t')[1].strip()
            pinyin_dict[pinyin] = pinyin_dict.get(pinyin, 0) + 1

    # 根据拼音是否重复，将行写入不同的文件
    with open('duplicate_temp.txt', 'w', encoding='utf-8') as f_dup, open(file_name + '_unique.txt', 'w', encoding='utf-8') as f_uniq:
        for line in lines:
            pinyin = line.split('\t')[1].strip()
            if pinyin_dict[pinyin] > 1:
                f_dup.write(line)
            else:
                f_uniq.write(line)

    # 读取 duplicate_temp.txt 文件的内容
    with open('duplicate_temp.txt', 'r', encoding='utf-8') as f:
        lines = f.readlines()

    # 将每一行转化为（拼音，行内容）的元组
    lines_with_pinyin = [(line.split('\t')[1].strip(), line) for line in lines]

    # 根据拼音对元组进行排序
    lines_with_pinyin.sort()

    # 提取排序后的行内容
    sorted_lines = [line for pinyin, line in lines_with_pinyin]

    # 将排序后的行内容写回文件
    with open(file_name+'_duplicate.txt', 'w', encoding='utf-8') as f:
        f.writelines(sorted_lines)

    os.remove("duplicate_temp.txt")


def let_it_happen(file_name):
    # 读取 file_name 文件
    with open(file_name, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    # 将行按拼音分类
    dict_lines = {}
    for line in lines:
        key = line.split('\t')[1].strip()  # 提取拼音部分作为键
        if key not in dict_lines:
            dict_lines[key] = [line]
        else:
            dict_lines[key].append(line)

    # 为每个拼音随机选择一行并写入 b.txt 文件
    with open(file_name + '_unique.txt', 'w', encoding='utf-8') as f:
        for key in dict_lines:
            f.write(random.choice(dict_lines[key]))


def clear_file(flag):

    # 使用 glob 获取所有文件
    files = glob.glob('./results/*')

    # 清理 results
    if flag == 1:
        for f in files:
            try:
                os.remove(f)
                print(f"Deleted file: {f}")
            except Exception as e:
                print(f"Cannot delete file {f}. Reason: {e}")

    # 清理干扰文件
    if flag == 2:
        for f in files:
            # 检查文件名是否不包含 "duplicate" 或 "unique"
            if "duplicate" not in f and "unique" not in f:
                # 尝试删除文件
                try:
                    os.remove(f)
                    print(f"Deleted file: {f}")
                except Exception as e:
                    print(f"Cannot delete file {f}. Reason: {e}")

    

def main():
    # 清理结果
    clear_file(1)
    # 遍历官方词库，获取编码和字词
    jd_bm()
    # 对编码结果的不同长度词组进行拆分
    split_from_jpy2jd(splited_files)
    # 与官方词库的编码进行匹配，获取空码词组
    for file in splited_files:
        get_result(file)
        sorted(file+"_result.txt")

    # 随缘词库，对重复的词组进行处理，只保留一个词组。
    # 如果你不想随缘，你可以自行对所有 *_duplicate.txt 进行处理
    let_it_happen("./results/length_3.txt_result.txt_duplicate.txt")
    let_it_happen("./results/length_4.txt_result.txt_duplicate.txt")
    let_it_happen("./results/length_5.txt_result.txt_duplicate.txt")

    # 清理干扰文件
    clear_file(2)



if __name__ == '__main__':
    main()
